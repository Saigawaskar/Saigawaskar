import os
import subprocess
import sys

def quick_install():
    print("🚀 Quick Setup Starting...")
    
    # Install required packages
    packages = [
        'pillow', 'pygame', 'tk', 'SpeechRecognition', 'pyttsx3', 
        'spacy', 'requests', 'wikipedia', 'psutil', 'pyautogui', 
        'pywhatkit', 'cx_Freeze'
    ]
    
    for package in packages:
        print(f"Installing {package}...")
        subprocess.run([sys.executable, "-m", "pip", "install", package])

    # Run setup assistant
    print("\nRunning setup assistant...")
    with open('setup_assistant.py', 'r') as file:
        exec(file.read())

    # Create desktop shortcut
    build_path = os.path.join(os.getcwd(), 'build')
    if os.path.exists(build_path):
        desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
        shortcut_path = os.path.join(desktop, 'SaiAI.lnk')
        os.system(f'mklink "{shortcut_path}" "{build_path}"')